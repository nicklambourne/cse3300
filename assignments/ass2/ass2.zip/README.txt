ICMP Client

Usage: python3 ping.py <host>
N.B: The script may need admin/sudo privileges.
e.g. sudo python3 ping.py google.com
